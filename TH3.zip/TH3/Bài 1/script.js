// Mảng lưu danh sách công việc (dạng đối tượng)
let tasks = [];

// Lấy các phần tử HTML
const input = document.getElementById("todo-input");
const addBtn = document.getElementById("add-btn");
const todoList = document.getElementById("todo-list");

// Lưu dữ liệu vào localStorage
function saveTasksToLocalStorage() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Tải dữ liệu từ localStorage
function loadTasksFromLocalStorage() {
  const data = localStorage.getItem("tasks");
  if (data) {
    tasks = JSON.parse(data);
  }
}

// Hàm thêm công việc
function addTask() {
  const taskText = input.value.trim();// Lấy và loại bỏ khoảng trắng đầu/cuối
  
  // Kiểm tra rỗng
  if (taskText === "") {
    alert("Vui lòng nhập nội dung công việc!");
    return;
  }

  // Tạo object task
  const task = {
    text: taskText,
    isDone: false
  };

  tasks.push(task);
  saveTasksToLocalStorage();
  renderTasks(); // Cập nhật lại danh sách

  input.value = ""; // Xóa ô nhập
}

// Hàm render lại danh sách công việc
function renderTasks() {
  todoList.innerHTML = ""; // Xóa danh sách cũ

  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.textContent = task.text;
    li.style.cursor = "pointer";

    // Gạch ngang nếu hoàn thành
    if (task.isDone) {
      li.style.textDecoration = "line-through";
      li.style.color = "gray";
    }

    // Gắn sự kiện click vào tiêu đề để đánh dấu hoàn thành
    li.addEventListener("click", () => {
      task.isDone = !task.isDone;
      saveTasksToLocalStorage();
      renderTasks();
    });

    // Nút xóa
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Xóa";
    deleteBtn.style.marginLeft = "10px";
    deleteBtn.addEventListener("click", (e) => {
      e.stopPropagation(); // Ngăn sự kiện click vào li
      tasks.splice(index, 1); // Xóa phần tử khỏi mảng
      saveTasksToLocalStorage();
      renderTasks();
    });

    li.appendChild(deleteBtn);
    todoList.appendChild(li);
  });
}

// Sự kiện cho nút Thêm và phím Enter
addBtn.addEventListener("click", addTask);
input.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    addTask();
  }
});

// Khi tải trang
loadTasksFromLocalStorage();
renderTasks();